#include "echoclient.h"

EchoClient::EchoClient(QWidget *parent)
    : QMainWindow(parent)
{
}

EchoClient::~EchoClient()
{

}
